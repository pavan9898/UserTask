
$(document).ready(function() {
    $('#login').on('click', function(e) {
    const user_ID = document.getElementById("login-user").value;
    const User_password = document.getElementById("login-password").value;
    if(user_ID ==""){
        document.getElementById('error').innerHTML="Please enter UserName";
    }else if(User_password==""){
        document.getElementById('error').innerHTML="Please enter password";
    }
    else
    {

        $.ajax({
            type: 'POST',
            url: 'php/login.php',
            dataType: "html",
            data: {
                user_name: user_ID,
                Userpassword:User_password
            },
            success: function(response,status,xhr) {
                if(response!="Login Successful")
                {
                    document.getElementById('error').innerHTML=response;
                }
                else
                {
                    
                    $.ajax({
                        type: 'POST',
                        url: 'php/profile.php',
                        dataType: "html",
                        data: {
                            user_name: user_ID
                        }})
                        
                    localStorage.setItem("loginUserId", user_ID);
                    
                     window.location.href = 'php/profile.php'; 
                    
                }
            },
            error:function(response,status,xhr)
            {alert(response);}
        });
    }
    })
})