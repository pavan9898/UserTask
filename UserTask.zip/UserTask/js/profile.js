$(document).ready(function() {
    $('#Update').on('click', function(e) {
    const user_name = document.getElementById("Profile_UserId").value;
    const Email_id = document.getElementById("Profile_Email").value;
    const Date_ofbirth = document.getElementById("Profile_DateOfBirth").value;Date_ofbirth
    const Contact_number= document.getElementById("Profile_ContactNumber").value;
    const Age_New = document.getElementById("Profile_Age").value;
    
    if(user_name==""){
        document.getElementById('error').innerHTML="Please enter UserName";
    }else if(Email_id==""){
        document.getElementById('error').innerHTML="Please enter EmailID";
     
    }else if(Contact_number==""){
        document.getElementById('error').innerHTML="Please enter Contact number";
        
    }else if(Date_ofbirth==""){
        document.getElementById('error').innerHTML="Please enter Date of Birth";
       
    }else if(Age_New==""){
        document.getElementById('error').innerHTML="Please enter Age";
                   
    }
    else
    {

    
        $.ajax({
            type: 'POST',
            url: 'profileupdate.php',
            dataType: "html",
            data: {
                user_name: user_name,
                Email: Email_id,
                Contactnumber:Contact_number,
                Dateofbirth:Date_ofbirth,
                Age:Age_New,

            },
            success: function(response,status,xhr) {
                if(response!="New Details Updated successfully")
                {
                    alert("Sorry some error occurred with the details entered. Please try after some time or try with new User ID")
                }
                else{
                document.getElementById('successmsg').innerHTML=response;
                }
            },
            error:function(response,status,xhr)
            {alert(response);}
        });
    }
    })
})
      
