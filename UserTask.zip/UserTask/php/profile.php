<?php
 $User_ID = "<script>document.write(localStorage.getItem('loginUserId'));</script>";
 $a = str_replace('"', '', $User_ID);
 session_start();
 $user_ID1 = $_SESSION['sessionuserName'];
 ?>

<!DOCTYPE html>
<html>
 <head>
 <title> Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="http://localhost/UserTask/js/profile.js"></script>
 </head>
<body>
<div class="forms-out">
    <div class="forms-in">
      <div id="profile-page">
<h2>Welcome <?php echo $user_ID1?></h2><hr>
<?php
$User_Name=strval($User_ID) ;
$myconn= require __DIR__ . "\databaseconnection.php";
$sql_query2 = "SELECT * FROM userdetails WHERE `UserName` LIKE '$user_ID1';";
$result = mysqli_query($myconn,$sql_query2);
if (mysqli_num_rows($result) > 0) {
?>
  <table id="students">

  <tr>
   <th>Username</th>
    <th>Email id</th>
    <th>DateOfBirth</th>
    <th>Contact Number</th>
    <th>Age</th>
  </tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
    <td><input type="text" id="Profile_UserId" readonly="readonly" disabled="disabled" value="<?php echo $row["UserName"] ;?>"></td>
    <td><input type="text" id="Profile_Email" value="<?php echo $row["Email"]; ?>"></td>
    <td><input type="date" id="Profile_DateOfBirth" value="<?php echo $row["DateOfBirth"]; ?>"></td>
    <td><input type="text" id="Profile_ContactNumber"value="<?php echo $row["ContactNumber"]; ?>"></td>
    <td><input type="text" id="Profile_Age" value="<?php echo $row["Age"]; ?>"></td>
</tr>
<?php
$i++;
}
?>
</table>
<button id="Update" >Update</button>
<span id="error" style="color:white;"></span><br />
<span id="successmsg" style="color:green;"></span><br />
 <?php
}
else{
    echo "No result found";
}
?>
      </div>
  
  </div>
</div>
 </body>
</html>
