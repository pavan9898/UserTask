<?php 

    $user_name = isset($_POST['user_name'])?$_POST['user_name']:"Pavan1";
    $email = isset($_POST['Email'])?$_POST['Email']:"pavan1234@gmail.com";
    $contactnumber = isset($_POST['Contactnumber'])?$_POST['Contactnumber']:123456;
    $dateofbirth = isset($_POST['Dateofbirth'])?$_POST['Dateofbirth']:"22-Feb-2023";
    $age = isset($_POST['Age'])?$_POST['Age']:22;
    $pass_word = isset($_POST["password"])?$_POST["password"]:"323232";
    
    $myconn= require __DIR__ . "\databaseconnection.php";
  
    $sql_query = "INSERT INTO userdetails (UserName,Email,DateOfBirth,ContactNumber,Age,Password)
    VALUES ('$user_name','$email','$dateofbirth',$contactnumber,$age,'$pass_word')";
        
        if (mysqli_query($myconn, $sql_query)) 
        {
           echo "New Details Entry inserted successfully";
        } 
        else
        {
           echo "Error: " . $sql . "" . mysqli_error($conn);
        }
        mysqli_close($conn);
   
   
    

?>