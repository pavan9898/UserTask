<?php 
    $user_ID = isset($_POST['user_name'])?$_POST['user_name']:"Pavan1";
    $User_Password = isset($_POST["Userpassword"])?$_POST["Userpassword"]:"323232";
    session_start();
    $_SESSION['sessionuserName'] = $user_ID;
    
    $myconn= require __DIR__ . "\databaseconnection.php";
  
    $sql_query1 = "SELECT Email FROM userdetails WHERE `UserName` LIKE '$user_ID' 
    AND `Password` LIKE '$User_Password';";
        $result = mysqli_query($myconn,$sql_query1);
        if(mysqli_num_rows($result) > 0 )
        {
        $row = mysqli_fetch_assoc($result);
        $email = $row["Email"];
        echo "Login Successful";
        }
        else
        {
        echo "Login Failed...Incorrect Email or Password...!";
        }
    
         
    
    

?>